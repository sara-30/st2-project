package com.upgrad.backendst2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendSt2Application {

	public static void main(String[] args) {
		SpringApplication.run(BackendSt2Application.class, args);
	}

}
